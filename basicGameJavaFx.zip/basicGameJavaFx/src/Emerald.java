import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Emerald extends Square{
    private  final String name="emerald";
    private final double worth=5000;
    private final double weight=60;
   
    public Emerald(int x, int y, Image image, boolean isFull,Canvas canvas,GraphicsContext gc) {
        super(x, y, image, isFull,canvas,gc);
         
  }

    public String getName() {
        return name;
    }

    public double getWorth() {
        return worth;
    }

    public double getWeight() {
        return weight;
    }

    @Override
    public void addEmpty() {
        // TODO Auto-generated method stub
        super.addEmpty();
    }


}
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;


public class Diaomond extends Square{
    private  final String name="diaomond";
    private final double worth=100000;
    private final double weight=100;
   
   public Diaomond(int x, int y, Image image, boolean isFull,Canvas canvas,GraphicsContext gc) {
        super(x, y, image, isFull,canvas,gc);
         
  }

    public String getName() {
        return name;
    }

    public double getWorth() {
        return worth;
    }

    public double getWeight() {
        return weight;
    }

    @Override
    public void addEmpty() {
        // TODO Auto-generated method stub
        super.addEmpty();
    }
  

}




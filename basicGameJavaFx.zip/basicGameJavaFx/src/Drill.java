import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Screen;

public class Drill {
    private final Image imageLeft = loadImage("/assets/drill/drill_01.png");
    private final Image imageRight = loadImage("/assets/drill/drill_55.png");
    private final Image imageUp = loadImage("/assets/drill/drill_51.png");
    private final Image imageDown = loadImage("/assets/drill/drill_40.png");


    private static final int TILE_SIZE = 50;
    private int x=0;
    private int y=0;
   
    private Canvas canvas;
    private Image currentImage;
    private double fuel=10000.000;
    private double storage;
    private double money=0;


    public Drill(Group pane,Canvas canvas) {
        this.canvas = canvas; // Canvas boyutları
        this.currentImage = imageLeft; // Başlangıç resmi
        updateCanvas();
    }

    private void updateCanvas() {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight()); // Önceki çizimleri temizle
        gc.drawImage(currentImage, x, y);
    }

    public void moveRight() {
        if (x + TILE_SIZE < canvas.getWidth() ) {
            x += TILE_SIZE;
            currentImage = imageRight;
            updateCanvas();
        }
    }

    public void moveLeft() {
        if (x - TILE_SIZE >= 0) {
            x -= TILE_SIZE;
            currentImage = imageLeft;
            updateCanvas();
        }
    }

    public void moveUp() {
        if (y - TILE_SIZE >= 0) {
            y -= TILE_SIZE;
            currentImage = imageUp;
            updateCanvas();
        }
    }

    public void moveDown() {
        if (y + TILE_SIZE <= canvas.getHeight() - currentImage.getHeight()) {
            y += TILE_SIZE;
            currentImage = imageDown;
            updateCanvas();
        }
    }

    // Getter ve Setter metodları fuel, storage ve money için eklenebilir
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    public double getFuel() {
        return fuel;
    }

    public void setFuel(double fuel) {
        this.fuel = fuel;
    }

    public double getStorage() {
        return storage;
    }

    public void setStorage(double storage) {
        this.storage = storage;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
    
    public void addMoney(Double double1){
        System.out.println("addMoney çağrıldı: " + double1);
        this.money += double1;
        System.out.println("Yeni money değeri: " + this.money);
    }
    public void addHaul(Double haul){
        System.out.println("addhaulçağrıldı: " + haul);
        this.storage += haul;
        System.out.println("Yeni yük değeri: " + this.storage);
    }
    public void reduceFuel(){
        this.fuel-=100;
    }
  
    
    public void consumingFuel(){
        this.fuel-=0.1;
        
    }
    public void gravity(){
        moveDown();
    }

    public Image loadImage(String filePath) {
        try {
            FileInputStream input = new FileInputStream(filePath);
            return new Image(input);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}



    

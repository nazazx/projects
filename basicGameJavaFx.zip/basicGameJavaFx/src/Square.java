import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

public class Square {
    private int x;
    private int y;
    private Image image;
    private boolean isFull;
    private Canvas canvas;
    private GraphicsContext gc;
    
    public Square(int x, int y, Image image, boolean isFull,Canvas canvas,GraphicsContext gc) {
        this.x = x;
        this.y = y;
        this.image = image;
        this.isFull = isFull;
        this.canvas=canvas;
        this.gc=gc;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public boolean isFull() {
        return isFull;
    }

    public void setFull(boolean isFull) {
        this.isFull = isFull;
    }

    public void addEmpty(){
        this.image = null;
        gc.clearRect(x * 50, y * 50,50, 50);
    }
    
    
    
}

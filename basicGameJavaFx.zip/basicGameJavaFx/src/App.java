import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.print.Collation;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.Axis.TickMark;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import javax.crypto.spec.DESKeySpec;




    /**
     * JavaFX App
     */
    public class App extends Application {
        private static final int TILE_SIZE = 50; // Karo boyutu
        private static final int WIDTH = 16;     // Arka plan genişliği (karo cinsinden)
        private static final int HEIGHT = 16;

        private ArrayList<Square> squares= new ArrayList<Square>(); 

        private Canvas statusCanvas = new Canvas(WIDTH * TILE_SIZE, HEIGHT*TILE_SIZE); // Durum için ayrılan yükseklik
        private GraphicsContext statusGc = statusCanvas.getGraphicsContext2D();

        @Override
        public void start(Stage primaryStage) throws IOException {
            Group root = new Group();
            Canvas canvas = new Canvas(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
            Canvas drillCanvas=new Canvas(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
            GraphicsContext gc=canvas.getGraphicsContext2D();     
            Scene scene = new Scene(root, WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
            Drill drill=new Drill(root,drillCanvas);
            
            Rectangle blueRectangle=new Rectangle(0,0,WIDTH*TILE_SIZE,TILE_SIZE*2);
            blueRectangle.setFill(Color.rgb(25, 25, 112));
            Rectangle orangeRectangle=new Rectangle(0,TILE_SIZE*2,WIDTH*TILE_SIZE,(HEIGHT-2)*TILE_SIZE);
            orangeRectangle.setFill(Color.rgb(160, 82,45));

            root.getChildren().addAll(blueRectangle,orangeRectangle);
            
            root.getChildren().addAll(canvas,drillCanvas);
          
            informing(root,statusCanvas,statusGc,drill);
            
           Timeline timeline=new Timeline(new KeyFrame(Duration.seconds(0.10),event ->{
                drill.consumingFuel();
                informing(root,statusCanvas,statusGc,drill);
           }));
           timeline.setCycleCount(timeline.INDEFINITE);
           timeline.play();

           Timeline timeline2=new Timeline(new KeyFrame(Duration.seconds(0.7),event ->{
            drill.consumingFuel();
            if(findSquare(drill.getX()/TILE_SIZE, (drill.getY()/TILE_SIZE)+1)==null){
                drill.gravity();
            }
            
            informing(root,statusCanvas,statusGc,drill);
       }));
       timeline2.setCycleCount(timeline.INDEFINITE);
       timeline2.play();
    
            scene.setOnKeyPressed(event -> {
               
    
                switch (event.getCode()) {
                    case UP:
                    if ((findSquare(drill.getX() / TILE_SIZE, (drill.getY() / TILE_SIZE) - 1) == null)&& !(findSquare(drill.getX() / TILE_SIZE, (drill.getY() / TILE_SIZE))instanceof Obstacle)) {
                        drill.moveUp(); 
                        drill.reduceFuel();
                        addEmpty(drill, root);
                        controlFuel(root, drill);
                        
                    }
                        informing(root,statusCanvas,statusGc,drill);
                        break;
                    case DOWN:
                    if (!(findSquare(drill.getX() / TILE_SIZE, (drill.getY() / TILE_SIZE)+1)instanceof Obstacle)){
                        drill.moveDown();
                        drill.reduceFuel();
                        addEmpty(drill,root);
                        controlFuel(root, drill);
                    }
                        
                        informing(root,statusCanvas,statusGc,drill);
                        break;
                    case RIGHT:
                    if (!(findSquare((drill.getX() / TILE_SIZE)+1, (drill.getY() / TILE_SIZE))instanceof Obstacle)){
                        drill.moveRight();
                        drill.reduceFuel();
                        addEmpty(drill,root);
                        controlFuel(root, drill);
                    }
                        informing(root,statusCanvas,statusGc,drill);
                        break;
                    case LEFT:
                    if (!(findSquare((drill.getX() / TILE_SIZE)-1, (drill.getY() / TILE_SIZE))instanceof Obstacle)){
                        drill.moveLeft();
                        drill.reduceFuel();
                        addEmpty(drill,root);
                        controlFuel(root, drill);
                    }
                        informing(root,statusCanvas,statusGc,drill);
                        break;
                }
            });


        List<java.nio.file.Path> paths = Files.list(Paths.get("src/assets/underground"))
                .filter(Files::isRegularFile)
                .collect(Collectors.toList());

            List<java.nio.file.Path> paths2=new ArrayList<>();
            for (java.nio.file.Path path:paths){
                if (path.endsWith("valuable_diamond.png")||path.endsWith("valuable_emerald.png")||path.endsWith("valuable_goldium.png")
                        ||path.endsWith("lava_01.png")||path.endsWith("obstacle_02.png")) {
                    paths2.add(path);
                }
                if (path.endsWith("soil_01.png")){
                    int n=0;
                    while (n<50){
                        paths2.add(path);
                        n++;
                    }
                }


            }


            loading(paths2, drillCanvas, gc);
        
            primaryStage.setScene(scene);
            primaryStage.show();
            root.requestFocus();
        }
    
        public static void main(String[] args) {
            launch(args);
        }



        public Square findSquare(int row,int column){
            for(Square square :squares ){
                if((square.getX()==row)&&(square.getY()==column)){
                    return square;
                }
            }
            return null;
            
        }

        public void informing(Group root,Canvas canvas,GraphicsContext gc ,Drill drill){
            

            gc.setFont(new Font("Arial",15));
            gc.setFill(Color.WHITE);
            String fuel=String.valueOf(drill.getFuel());
            String storage=String.valueOf(drill.getStorage());
            String money=String.valueOf(drill.getMoney());
            gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

            gc.fillText("Fuel: "+fuel, 0, 40);
            gc.fillText("Haul: "+storage, 0, 65);
            gc.fillText("Money: "+money, 0, 90);

            if (!root.getChildren().contains(canvas)) {
                root.getChildren().add(canvas);
            }

        }

        public void gameOver(Group root,Drill drill){
            Rectangle rectangle =new Rectangle(0,0,WIDTH*TILE_SIZE,HEIGHT*TILE_SIZE);
            rectangle.setFill(Color.GREEN);
            root.getChildren().addAll(rectangle);

            Canvas canvas=new Canvas(800,800);
            GraphicsContext gc=canvas.getGraphicsContext2D();
            gc.setFont(new Font("Arial",40));

            gc.setFill(Color.WHITE);
            gc.fillText("GAME OVER", 250, 300);
            
            
            String money=String.valueOf(drill.getMoney());
            gc.fillText("COLLECTED MONEY: "+money, 100, 400);
            root.getChildren().addAll(canvas);
        }

        public void gameOver2(Group root){
            Rectangle rectangle=new Rectangle(0,0,WIDTH*TILE_SIZE,HEIGHT*TILE_SIZE);
            rectangle.setFill(Color.RED);
            root.getChildren().add(rectangle);

            Canvas canvas=new Canvas(800,800);
            GraphicsContext gc=canvas.getGraphicsContext2D();
            gc.setFont(new Font("Arial",40));

            gc.setFill(Color.WHITE);
            gc.fillText("GAME OVER", 250, 400);

            root.getChildren().add(canvas);

        }

       public void addEmpty(Drill drill,Group root){
            Square square=findSquare(drill.getX()/TILE_SIZE, drill.getY()/TILE_SIZE);;
            if(square!=null){
            if(square instanceof Diaomond){
                System.out.println("diaomand");
                drill.addMoney(((Diaomond) square).getWorth());
                drill.addHaul(((Diaomond)square).getWeight());
                square.addEmpty();
                squares.remove(square);
               
            }
            else if(square instanceof Emerald){
                drill.addMoney(((Emerald) square).getWorth());
                drill.addHaul(((Emerald)square).getWeight());
                square.addEmpty();
                squares.remove(square);
            }
            else if(square instanceof Goldium){
                drill.addMoney(((Goldium) square).getWorth());
                drill.addHaul(((Goldium)square).getWeight());
                square.addEmpty();
                squares.remove(square);
            }
            else if(square instanceof Lava){
               gameOver2(root);
            }
            else {
                square.addEmpty();
                squares.remove(square);
            }
        
            }
            
            }
            public void loading(List<java.nio.file.Path> paths,Canvas canvas,GraphicsContext gc){
            for (int y = 0; y < HEIGHT; y++) {
                for (int x = 0; x < WIDTH; x++) {
                    if((y>=3&&y<HEIGHT && (x==0 || x==WIDTH-1))||(y==HEIGHT-1)){
                        
                        Image tileImage= new Image(getClass().getResourceAsStream("/underground/obstacle_01.png"));
                        squares.add(new Obstacle(x, y, tileImage, true,canvas,gc));
                        
                        gc.drawImage(tileImage, x*TILE_SIZE, y*TILE_SIZE);
                    }
                    else if(y<2){
                       continue;
                    }
                    else if(y==2){
                        Image tileImage= new Image(getClass().getResourceAsStream("/underground/top_01.png"));
                        squares.add(new Square(x, y, tileImage, true,canvas,gc));
                        gc.drawImage(tileImage, x*TILE_SIZE, y*TILE_SIZE);
                    }
                   else{



                    Random rand = new Random();
                    java.nio.file.Path path = paths.get(rand.nextInt(paths.size()));
                    Image tileImage = new Image(path.toUri().toString());


                    if(path.endsWith("lava_01.png")){
                        squares.add(new Lava(x, y, tileImage, true,canvas,gc));
                    }
                    else if(path.endsWith("valuable_diamond.png")){
                        squares.add(new Diaomond(x, y, tileImage, true,canvas,gc));
                    }
                    else if(path.endsWith("valuable_goldium.png")){
                        squares.add(new Goldium(x, y, tileImage, true,canvas,gc));
                    }
                    else if(path.endsWith("valuable_emerald.png")){
                        squares.add(new Emerald(x, y, tileImage, true,canvas,gc));
                    }
                    else if (path.endsWith("obstacle_02.png")){
                            squares.add(new Obstacle(x, y, tileImage, true, canvas, gc));
                    }
                    else{
                        squares.add(new Soil(x, y, tileImage, true,canvas,gc));
                    }

                    gc.drawImage(tileImage, x*TILE_SIZE, y*TILE_SIZE);

                   }
                }

            }
        }
            public void controlFuel(Group root,Drill drill){
                if(drill.getFuel()<=0){
                    gameOver(root, drill);;
                }
                else{
                    return;
                }
            }
            
        }

 
    

    
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Obstacle  extends Square{
    

   public Obstacle(int x, int y, Image image, boolean isFull,Canvas canvas,GraphicsContext gc) {
        super(x, y, image, isFull,canvas,gc);
         
  }
    
    
}
